# Importando bibliotecas necessárias
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.feature_selection import SelectKBest, f_classif

# Etapa 1: Leitura dos Dados
def load_data(file_path):
    data = pd.read_csv(file_path)
    return data

# Etapa 2: Divisão Treino e Teste
def split_data(data, target_column):
    X = data.drop(target_column, axis=1)
    y = data[target_column]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    return X_train, X_test, y_train, y_test

# Etapa 3: Conversão de Atributos
def encode_categorical_attributes(data):
    encoder = OneHotEncoder()
    # Vamos supor que a coluna 'categoria' é nominal e precisa ser convertida
    encoded_data = encoder.fit_transform(data[['categoria']])
    return encoded_data

# Etapa 4: Padronização de Atributos Numéricos
def standardize_numeric_attributes(X_train, X_test):
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled, X_test_scaled

# Etapa 5: Seleção de Atributos
def select_features(X_train, X_test, y_train, k=5):
    selector = SelectKBest(f_classif, k=k)
    X_train_selected = selector.fit_transform(X_train, y_train)
    X_test_selected = selector.transform(X_test)
    return X_train_selected, X_test_selected

# Etapa 6: Aplicação do Algoritmo MLP
def train_mlp(X_train, X_test, y_train, y_test):
    mlp_classifier = MLPClassifier(hidden_layer_sizes=(100,), max_iter=1000, random_state=42)
    mlp_classifier.fit(X_train, y_train)
    y_pred = mlp_classifier.predict(X_test)
    return y_pred

# Etapa 7: Aplicação de Outra Rede Neural
def train_another_mlp(X_train, X_test, y_train, y_test):
    # Utilizando outra configuração de parâmetros
    another_mlp_classifier = MLPClassifier(hidden_layer_sizes=(50, 25), max_iter=1000, random_state=42)
    another_mlp_classifier.fit(X_train, y_train)
    y_pred_another_mlp = another_mlp_classifier.predict(X_test)
    return y_pred_another_mlp

# Etapa 8: Validar os Modelos
def evaluate_model(y_test, y_pred):
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)
    return accuracy, report

# Carregando dados 
data = load_data("bcdata.sgs.25379.csv")

# Dividindo dados
X_train, X_test, y_train, y_test = split_data(data, "classe")

# Convertendo atributos
X_train_encoded = encode_categorical_attributes(X_train)
X_test_encoded = encode_categorical_attributes(X_test)

# Padronizando atributos numéricos
X_train_scaled, X_test_scaled = standardize_numeric_attributes(X_train_encoded, X_test_encoded)

# Selecionando atributos
X_train_selected, X_test_selected = select_features(X_train_scaled, X_test_scaled, y_train)

# Treinando e avaliando o modelo MLP
y_pred_mlp = train_mlp(X_train_scaled, X_test_scaled, y_train, y_test)
accuracy_mlp, report_mlp = evaluate_model(y_test, y_pred_mlp)

# Imprimindo resultados
print(f"Accuracy MLP: {accuracy_mlp}")
print("Classification Report MLP:")
print(report_mlp)

# Treinando e avaliando outra rede neural MLP
y_pred_another_mlp = train_another_mlp(X_train_scaled, X_test_scaled, y_train, y_test)
accuracy_another_mlp, report_another_mlp = evaluate_model(y_test, y_pred_another_mlp)

# Imprimindo resultados
print(f"Accuracy Another MLP: {accuracy_another_mlp}")
print("Classification Report Another MLP:")
print(report_another_mlp)

# Documentação

#Este notebook Python implementa um modelo de Rede Neural MLP para prever a variável alvo 'classe' em um conjunto de dados. As etapas incluem leitura dos dados, divisão entre conjunto de treino e teste, conversão de atributos categóricos, padronização de atributos numéricos, seleção de atributos, aplicação do algoritmo MLP, aplicação de outra rede neural, e validação dos modelos.

#1. Leitura dos Dados:
 #  - Utilizei a função load_data para ler os dados do arquivo CSV especificado.

#2. Divisão Treino e Teste:
  # - Utilizei a função split_data para dividir o conjunto de dados em conjuntos de treino e teste.

#3. Conversão de Atributos:
 #  - Utilizei a função encode_categorical_attributes para converter atributos categóricos em atributos numéricos binários.

#4. Padronização de Atributos Numéricos:
#   - Utilizei a função standardize_numeric_attributes para padronizar os atributos numéricos do conjunto de dados.

#5. Seleção de Atributos:
 #  - Utilizei a função select_features para selecionar os atributos mais relevantes.

#6. Aplicação do Algoritmo MLP:
 #  - Utilizei a função train_mlp para treinar e avaliar um modelo MLP com uma configuração específica de parâmetros.

#7. Aplicação de Outra Rede Neural:
 #  - Utilizei a função train_another_mlp para treinar e avaliar outra rede neural com uma configuração diferente.

#8. Validar os Modelos:
 #  - Utilizei a função evaluate_model para obter métricas de avaliação.
